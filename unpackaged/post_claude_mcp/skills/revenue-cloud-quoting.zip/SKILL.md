---
name: revenue-cloud-quoting
description: >
  Route Salesforce Revenue Cloud quoting in Claude Desktop. After reconnect
  call getRevenueCloudQuotingCatalog, then findOpenQuotes with opportunityName.
  Quotes, options, bundles, recaps, PDF, submit/decide approval, order,
  amend, renew/cancel, unsent Gmail draft, first-ramp in chat. Never insert
  Quote/Order/Asset/Account; never update Asset; never send mail. Dates
  yyyy-mm-dd. New mix: one create with linesJson + opportunityName + quoteName.
  Same email again: reuse or update, never a second Draft. No account: confirm
  then prospect (address or useDemoAddress). Own SKU: amend, not create.
  Email with a Drive Sheet or PDF: open Drive and quote those lines; do
  not wait to be told. Call or calendar recap: open Calendar (and Drive
  notes) and quote; do not wait to be told. Close a named deal: submit,
  order, activate. Customer pack: explain, PDF, unsent draft
  (bodyDisplay as-is; no Lightning URLs). Q-Rack qty 1. Add-line
  inherits quote term. PDF+email in one turn; never Draft after Preview.
---

# Revenue Cloud quoting

You have **Revenue Cloud Quoting** MCP tools plus Salesforce **SObject All** for
reads. **Gmail** and **Microsoft 365 / Outlook** connectors (when enabled on
this chat) are for reading customer mail only. **Google Calendar** (when
enabled on this chat) is for finding a meeting / call recap — do that as
part of inbound quote, without being asked. Never create, update, or delete
calendar events. Never send a calendar invite. **Google Drive** (when
enabled on this chat) is for opening a Sheet, Doc, or PDF the email or
calendar event links to — do that without being asked. A PDF uploaded in
this chat is the same: read it, then quote. SObject All is for lookup and
recap only. Never insert `Quote`, `QuoteLineItem`, `Order`, `OrderItem`, or
`Asset` rows yourself. Never update `Asset` rows to change quantity. Never use
SObject All to explain a price, rebuild a waterfall, or recap installed
base — call `explainRevenueCloudQuotePrice` or
`getRevenueCloudInstalledBase` instead. Never send mail to the customer.

## Which tool

After reconnect, or when a tool parameter such as `startDate` is “unknown”,
call **`getRevenueCloudQuotingCatalog` first**. If that tool is missing,
stop and tell the user to reconnect MCP and re-upload this skill.

| User intent | Tool |
|---|---|
| After reconnect / stale tools / skill version | `getRevenueCloudQuotingCatalog` |
| Two or more commercial alternatives under **one Opportunity** (term, mix, discount) | `buildRevenueCloudQuoteOptions` |
| One new Draft quote | `createRevenueCloudQuote` (always pass `opportunityName` + `quoteName` + `linesJson`) |
| Prospect / sender not in Salesforce | Confirm with the user, then `createRevenueCloudProspect`, then Create Quote — never SObject-insert Account |
| Add catalog products to an existing Draft quote | `addProductToRevenueCloudQuote` with `linesJson` for every new SKU in that call. New lines inherit the quote `StartDate`/`EndDate` (do not pass `termMonths` unless this SKU should differ). Recap `lineSummaryDisplay` + Open Quote. Do **not** explain or preview after add. Q-Rack 750 / One-Time hardware bundle: quantity 1. If Salesforce returns fractional quantity and qty > 1, immediately add again at quantity 1 — do not stop the quote |
| Which Draft quote / reconnect / several Acme deals | `findRevenueCloudOpenQuotes` with `opportunityName` from the email — ask only if several rows |
| See bundle option groups / current picks | `describeRevenueCloudBundleConfiguration` |
| Save bundle picks the user chose from describe | `configureRevenueCloudBundle` |
| Percent off | `applyRevenueCloudQuoteDiscount` (discount only) or `updateRevenueCloudQuoteLines` when also changing qty or term |
| Change quantity, term, start date, quote name, or remove a line on an existing Draft | `updateRevenueCloudQuoteLines` with `quantitiesJson` (quantity 0 or `"remove":true` drops that parent line), `termMonths`, `startDate`, and/or `quoteName` — never rebuild, never SObject-delete QuoteLineItem |
| What-if on a live Draft (36 months, 15% off, 20 more seats, TCV) | One `updateRevenueCloudQuoteLines`, then `getRevenueCloudBillingAndUsage` for TCV (GrandTotal). Never rebuild, never Build Quote Options |
| Customer pack (explain + proposal PDF + unsent email) | Explain once, then preview until `bodyDisplay` in **this turn**. **Never wait/Pause. Never ask the user to prompt again.** Gmail that HTML. **Never** `draftRevenueCloudCustomerReply` after preview. Never send |
| Close / take a named deal to order and activate | Find the quote, `getRevenueCloudDealStatus`, submit if Draft, decide only if this user is the assignee, `createRevenueCloudOrderFromQuote`, `activateRevenueCloudOrder`, then installed base. Stop if approval is waiting on someone else |
| Recap lines and prices | `getRevenueCloudQuoteSummary` |
| Why this price / walk the customer through list → final | `explainRevenueCloudQuotePrice` |
| Preview the order form / quote proposal PDF | `previewRevenueCloudQuoteDocument`. If `isPartial`, call again **immediately** until `bodyDisplay`. Never wait/Pause. Never ask the user to retry. Gmail `bodyDisplay`; do not Draft |
| Submit a Draft quote that has lines | `submitRevenueCloudQuoteForApproval` |
| Approve or reject a submitted quote (assignee) | `decideRevenueCloudQuoteApproval` (`decision=approve` or `reject`) |
| Create an order from a quote | `createRevenueCloudOrderFromQuote` |
| Activate an order so Salesforce creates assets | `activateRevenueCloudOrder` |
| Amend an existing asset (quantity change) | `amendRevenueCloudAsset` (pass `opportunityName`) |
| What they own / MRR / ARR / current discount / how often they add on | `getRevenueCloudInstalledBase` — period Discount, never quotes, never `Asset.CurrentMrr` |
| Quote vs what they own (qty / discount) | `compareRevenueCloudQuoteToInstalledBase` — quote 30% off is not owned Discount |
| Where is this deal / approval / order / assets | `getRevenueCloudDealStatus` — read only |
| Renew or cancel what they own | Confirm first, then `renewOrCancelRevenueCloudAsset` (`action=renew` or `cancel`). Then create order + activate. Never PATCH Asset |
| Draft a customer reply | `draftRevenueCloudCustomerReply` — Gmail draft/create with `bodyDisplay` verbatim. No Lightning URLs in the email. Never send |
| Add a PDF link to an existing unsent Gmail draft | `draftRevenueCloudCustomerReply` **once**, then **update that Gmail draft** with the proposal PDF `<a href>`. Do **not** preview. Do **not** explain. Do **not** create a second draft |
| Draft / refresh the email for the current quote | `previewRevenueCloudQuoteDocument` until `bodyDisplay` **in this turn**, then update Gmail. Never wait. Never ask them to prompt again. **Never** `draftRevenueCloudCustomerReply` |
| Ramp 10/20/30 on an existing Draft | `applyRevenueCloudQuoteRamp` — describe, create the first yearly schedule, or patch qty |
| Next bill / TCV / usage | `getRevenueCloudBillingAndUsage` — TCV is quote GrandTotal, not ARR |
| Build a quote from a customer email | Search Gmail or Outlook. If the mail has a Drive Sheet or PDF (link or Drive-attached), open it with **Google Drive** and take product/qty from that file — do not wait for “read the sheet/PDF.” A PDF uploaded in this chat: read it the same way. Then one `createRevenueCloudQuote` with `opportunityName`, `quoteName`, and `linesJson`. If `alreadyExisted`, update — do not create again |
| Quote from a meeting / call / calendar recap | Search **Google Calendar** (or Microsoft 365 calendar if that is what is on). Open the event description and any Drive notes now — do not wait for “read the recap.” Then one `createRevenueCloudQuote` with `opportunityName`, `quoteName`, `linesJson`, `startDate` from the event, `contactEmail` from a customer attendee. If `alreadyExisted`, update — do not create again |
| Later email / reconnect on an existing quote | `findRevenueCloudOpenQuotes` with that `opportunityName`, then `updateRevenueCloudQuoteLines` — never a second quote |

If the user asks for “three options”, “alternatives”, “good / better / best”,
or several quotes on the same deal, call **Build Quote Options** with every
option in `optionsJson` **once**. The tool places the first option of each
product mix, then Deep Clones siblings and patches term/discount. It only
returns `remainingOptionsJson` if Salesforce CPU forces a pause. In that case
**immediately call again** with the same `accountName`, same `opportunityName`,
and `optionsJson` = `remainingOptionsJson`. Do not ask the user. Do not create a
new Opportunity. Repeat until `remainingOptionsJson` is blank, then render
the visual card. Do not loop Create Quote yourself.

## Record links (required)

Claude Desktop has no Salesforce record card. Whenever a tool returns
`quoteUrl`, `opportunityUrl`, `orderUrl`, `assetUrl`, `pdfUrl`, or asset
links, put those in the user-facing reply as markdown links:

- `[Open Quote](quoteUrl)`
- `[Open Opportunity](opportunityUrl)`
- `[Open Order](orderUrl)`
- `[Open Asset](assetUrl)` or from `assetsDisplay`
- `[Open PDF](pdfUrl)`

Do this after create, add-line, configure, discount, summary, explain,
preview document, submit, create-order, activate, amend, prospect,
find-open-quotes, compare, and Build Quote Options. Echo markdown already
present in `message`, `comparisonDisplay`, `resultsDisplay`,
`summaryDisplay`, or `assetsDisplay`. Never paste a raw Salesforce Id as
the thing to click. Also render `[Open Account](accountUrl)` /
`[Open Contact](contactUrl)` when those fields are set.

`quoteUrl` and `pdfUrl` are **Lightning** pages. Put them in Claude chat
only. Never put `/lightning/r/` links, Open Quote, or Open PDF in a Gmail
or Outlook draft — the customer cannot log in. Use `coachDisplay` from
`draftRevenueCloudCustomerReply` for those AE links.

## Next-best-action (required after mutates)

After every **successful** create, add-line, update-lines, discount, ramp,
configure, submit, decide, create-order, activate, amend, renew/cancel,
customer pack, or Build Quote Options, end the user-facing reply with
**one** short Next line. Do not add it after catalog ping, explain-only,
deal-status-only, or when you stopped to ask a question.

| Just happened | Next line |
|---|---|
| New or updated Draft (create / add / update / discount / ramp / configure / options) | Next: ramp 10/20/30, change term or discount, submit for approval, or prepare the customer pack. |
| Customer pack | Next: submit for approval, or take this deal to an order. |
| Submitted, waiting on someone else | Next: check deal status, or approve if you are the assignee. |
| Approved | Next: create the order and activate. |
| Order created, not activated | Next: activate so Salesforce creates assets. |
| Activated / amend or renew quote ready | Next: recap installed base, or compare this quote to what they own. (After amend/renew quote: create the order and activate.) |

Do not list every option. Use the matching row. Keep it one sentence.

## Build Quote Options

Pass `accountName`, optional `opportunityName` (defaults to
`<Account> Commercial Options`), and `optionsJson`:

```json
[
  {
    "quoteName": "12-Month Essentials",
    "termMonths": 12,
    "discountPercent": 0,
    "lines": [
      {
        "product": "QuantumBit Complete",
        "quantity": 10,
        "configure": "QuantumBit Database, Software Maintenance"
      }
    ]
  },
  {
    "quoteName": "24-Month Growth",
    "termMonths": 24,
    "discountPercent": 5,
    "lines": [
      { "product": "QuantumBit Complete", "quantity": 10 },
      { "product": "Q-Rack 750", "quantity": 1 }
    ]
  }
]
```

`configure` is optional and only for bundle parents. Use catalog names or SKUs
from this org, not products from another demo.

`termMonths` is the **subscription term** on TermDefined lines (12 → 1 Annual,
24 → 2 Annual, 36 → 3 Annual), not only the quote header dates. One-Time
hardware is not given an end date.

Year-over-year **group ramps** (qty 10 / 20 / 30 as segments) are not in this
tool. Build the quotes here, then `applyRevenueCloudQuoteRamp` with
`segmentsJson` to create or patch the yearly schedule.

### Visual recap (required)

After `buildRevenueCloudQuoteOptions` succeeds, **do not** dump the raw line
list as the main answer. Render `comparisonDisplay` as a **visual card**
(artifact if the client supports it):

1. Title: `<Account> Quote Options`
2. Subtitle: N options · opportunity name
3. Clickable **Open Opportunity** from `opportunityUrl`
4. Three stats: Lowest Net, Highest Net, Range
5. One row per option: name, term, line count, net, **Open** quote link

Keep one short sentence under the card. Put line-item detail behind a follow-up
("show lines") instead of in the first message.

Do **not** render the final card until `remainingOptionsJson` is blank. A
partial call may show 1 of 3 options — continue the tool, then show the card.

## Inbound quote from calendar (call / meeting / recap)

When they ask to **build a quote from a call, meeting, calendar event, or
call recap** (“quote my Acme call”, “today’s meeting”, “the notes on my
calendar”):

1. Use **Google Calendar** — not Salesforce — to find the event. If
   Microsoft 365 is on and exposes calendar events, same intent.
   - Search by account name + today / this week. Do not dump the calendar.
   - Several matching events: ask which row. Do not guess.
   - Calendar off or missing: say so and ask them to enable **Google
     Calendar** on this chat. Do not invent an event. If they said
     “email,” follow **Inbound quote from email** instead.
2. **Read the recap now.** Do **not** ask whether to open the notes. Do
   **not** wait for “read the recap” or “pull in those details.”
   - Event description first, if it already has product/qty.
   - Then any Drive Doc / Sheet / PDF attached to the event, or a Drive
     URL in the description. Call **Google Drive** immediately (same
     extract rules as inbound email step 2). Prefer a Sheet over a Doc
     or PDF when both exist.
   - Meet / Zoom **recording** links only: say you cannot transcribe
     video. Do not invent lines from the title.
   - Vague notes (“they want more licenses”) with no SKU or qty: show
     what you extracted and wait. Do not invent SKUs.
   - Drive off and the **only** lines are in an attached file: ask them
     to enable **Google Drive**. Do not invent SKUs.
   - Do **not** treat our Quote Proposal PDF as an inbound recap.
3. Map the event, then follow **Inbound quote from email** steps 3–8
   (extract, prospect, confirm, one Create Quote):
   - `accountName` / `opportunityName` / `quoteName` from the event
     title. Use a stable deal name (`Acme Expansion`), not
     `Acme <> AE weekly`.
   - `startDate` = the event date (`yyyy-mm-dd`). Do not ask if the
     event has a date.
   - `contactEmail` = the first attendee who is not the connected user
     / AE. Do not use your own address as the contact.
   - `linesJson` from the description or Drive notes.
4. Same ask again: `alreadyExisted` or Find Open Quotes, then update —
   never a second Draft.
5. A **later** meeting with updated qty / term: find that newest event
   and its notes, then follow **Follow-up email (qty / term revision)**
   steps 3–6. Do not create another quote.

If they named **both** a meeting and an email: Calendar for the pin
(`opportunityName`, `startDate`, attendees) and notes; Gmail only if the
event has no usable lines.

Never create, update, or delete calendar events. Never send a calendar
invite.

## Inbound quote from email

If they say **update / revise / latest quantities** on an existing quote,
or the newest mail is clearly a change to a deal already quoted, skip this
section and follow **Follow-up email (qty revision)** below. If they named
a **call / meeting / calendar recap**, use **Inbound quote from calendar**
instead.

When the user asks to **build a new quote** from email (“latest Acme email”,
“the customer request in my inbox”, a named sender):

1. Use **Gmail** or **Microsoft 365 / Outlook** — not Salesforce — to find
   and read the message.
   - Gmail: `search_threads` (account name, quote/pricing, newest first),
     then `get_thread` on the match.
   - Outlook: the mail search/read tools that connector exposes. Same intent.
   - Search narrowly. Do not dump the inbox.
   - If those connectors are missing or off, say so and ask them to enable
     Gmail or Microsoft 365 on this chat, or paste the email. Do not invent
     an inbox.
2. **Spreadsheet or PDF in that mail — open it now.** After you have the
   message, look for a Google Sheet / Drive / PDF URL
   (`docs.google.com/spreadsheets`, `drive.google.com`, a `.pdf` Drive
   link), or Gmail “inserted from Drive” attachment metadata (file id or
   URL, including PDF). If any of those exist:
   - Call **Google Drive** immediately (the search / open / read tools that
     connector exposes). Do **not** ask whether to read the file. Do **not**
     wait for “read the sheet,” “read the PDF,” or “pull in those details.”
   - Map product/qty to `linesJson`: Product / SKU / Name / Item →
     `product`; Quantity / Qty → `quantity`. A Discount / Discount %
     column or mention is discount language, not a price override. Ignore
     Unit Price / List / Amount — Create Quote prices from Salesforce.
   - Prefer a **Sheet** over a PDF when both exist; reconcile, do not drop
     sheet rows. Prefer file rows over a vague body (“please quote the
     attached”). If the body also names products, reconcile; do not drop
     file rows.
   - Several PDFs: pick the one named quote / RFP / BOM / request, or ask.
     Do not merge blindly.
   - Recap the parsed lines on the confirmation card, then continue. If
     you cannot find readable products, show what you extracted and wait.
     Do not invent SKUs.
   - Scanned / image-only PDF: try Drive; if there is no selectable text,
     say so. A PDF uploaded in this chat is the fallback (you can read
     pages there).
   - Drive off or missing, and the **only** lines are in the Sheet or PDF:
     stop and ask them to enable **Google Drive** on this chat. Do not
     invent SKUs.
   - Drive off, but the body already has product/qty: quote from the body
     and say the file was skipped because Drive is off.
   - A downloaded `.xlsx` / `.csv` / `.pdf` attached as a normal email
     file, with **no** Drive URL: Gmail cannot read the cells or pages.
     Say that. Same fallback (body lines, or stop). Do not invent lines
     from the filename.
   - A spreadsheet or PDF uploaded in this Claude chat: read that file
     the same way.
   - Do **not** treat our **Quote Proposal** PDF (`previewRevenueCloudQuoteDocument`
     / `pdfUrl`) as an inbound customer request.
3. Extract: sender name and email, account hint, products and quantities
   (from the sheet or PDF when step 2 ran),
   term, discount language, **new sale vs change to something they already
   own**. If they already own that SKU (`getRevenueCloudInstalledBase`),
   this is an **amend** (`amendRevenueCloudAsset` with a delta and
   `startDate`), not a new quote. Pass `opportunityName`.
4. Do **not** query `Product2` (or the catalog) with SObject All. Create Quote
   resolves product names. Use SObject All only when the sender is unclear,
   or Asset when this looks like an amendment. If **no Account** matches the
   company: show the parsed company/contact, **wait for confirm**, then
   `createRevenueCloudProspect` (never SObject-insert Account), then Create
   Quote. If a similar account exists, the tool asks — do not create a
   duplicate.
5. If they already named a **new** Opportunity, do **not** stop to confirm
   the Opportunity and do **not** ask which existing Opportunity to use.
   Otherwise show a short confirmation card (account, lines) and wait.
6. One mix: **one** `createRevenueCloudQuote` call. Do **not** call
   `addProductToRevenueCloudQuote` per SKU. Do **not** call
   `buildRevenueCloudQuoteOptions`. Pass:
   - `accountName`
   - `quoteName` (stable name from the subject or the name they chose)
   - `opportunityName` (**required** when the account has several open
     deals — never omit it on Acme)
   - `contactEmail` when you have the sender
   - `termMonths` from the email (12 if they asked for 12 months)
   - `linesJson`: `[{"product":"QuantumBit Database","quantity":10}, ...]`
     using the names from the sheet or PDF when step 2 ran, otherwise the
     email body. **Q-Rack 750** (and other One-Time hardware bundles):
     pass `quantity` **1**, even if the mail asked for 8. Qty > 1 fails
     Salesforce bundle validation (`Cannot have a fractional quantity` on
     a child component). If Create Quote still reports that error, immediately
     `addProductToRevenueCloudQuote` with that product at quantity 1. Do
     not create another quote. Say it is sold per rack.
   If Create Quote returns `alreadyExisted=true`, **do not add lines**.
   Call `updateRevenueCloudQuoteLines` or `addProductToRevenueCloudQuote`.
   If the message says they already own a product, confirm amend vs new
   sale before submitting.
   - Describe/configure only if a returned line is a bundle that still needs
     picks. Discount only if the email, sheet, or PDF asked for one.
7. Recap `linesDisplay` (or the line list in `message`) and render
   **Open Quote** / **Open Opportunity**. Do **not** call
   `previewRevenueCloudQuoteDocument` unless they asked for the order form,
   proposal, or PDF. Do **not** call `getRevenueCloudQuoteSummary`.
8. **Never** `send_message`, `reply`, Outlook send, or email a PDF to the
   customer. Draft a reply only if they explicitly ask — leave it unsent.
   Do not write “reconciling totals” or wait messages. If they already said
   to create a new Opportunity, do not ask which existing one to use.

## Add products to an existing Draft

When the user wants to **add** a catalog product to a quote that already
has lines (new SKU, not a quantity change on an existing line):

1. Call **`addProductToRevenueCloudQuote` once** with that `quoteId` and
   `linesJson` for every new SKU. Do not add-product per SKU. Do not
   retry other payload shapes.
2. **Term.** New lines inherit the quote `StartDate` / `EndDate`. If the
   quote is 36 months, the new line is 36 months. Pass `termMonths` (or
   a per-row `termMonths` in `linesJson`) **only** when they said this
   SKU should be a different term (for example 12 months). Do **not**
   call `updateRevenueCloudQuoteLines` afterward just to stretch the
   new line to the quote term.
3. **Discount.** Do not apply the quote’s existing percent off to the
   new line unless they asked. If they said not to discount this line,
   add only — never `applyRevenueCloudQuoteDiscount` in the same turn.
4. Recap `lineSummaryDisplay` (includes the inherited term) and
   **Open Quote**. Stop.
5. Do **not** call `explainRevenueCloudQuotePrice` after add unless they
   asked why the price is what it is. Do **not** preview the PDF. Do
   **not** `getRevenueCloudQuoteSummary` unless the add tool timed out.
6. If Add Product fails with a connector timeout (`isn't responding`)
   or similar: **do not retry add**, do not explain, do not preview.
   Call `getRevenueCloudQuoteSummary` once and Open Quote — the line
   often already committed. Then stop.

## Update quantity, term, start date, discount, or quote name

Works from **chat** (verbal request) or from email. No inbox required.

When the user wants to change quantity, **remove a line**, subscription
term, start date, a percent off, and/or the **quote name** on a Draft
quote:

1. Call **`updateRevenueCloudQuoteLines` once** with the `quoteId` you already
   have. Pass `quantitiesJson`, `termMonths`, `startDate`,
   `discountPercentage`, and `quoteName` in the **same** call when they
   asked for more than one of those. Rename only when they asked — do
   not invent a new name after a term change. To **remove** a parent
   line, pass quantity `0` or `"remove":true` (e.g.
   `[{"product":"Software Maintenance","quantity":0}]`). Do not set
   quantity 0 on a bundle child — remove or reconfigure the parent.
   ```json
   [{"product":"QuantumBit Database","quantity":20},{"product":"Q-Rack 750","quantity":3}]
   ```
   Convert spoken terms to months (`5 years` → `termMonths=60`). Convert
   spoken dates to `yyyy-mm-dd` (`12/1/2026` → `startDate=2026-12-01`).
   Keep the existing start date **only** when they did not give a new one.
2. Do **not** rebuild the quote. Do **not** create a new Opportunity. Do
   **not** call `buildRevenueCloudQuoteOptions` for a term change. Do
   **not** call `addProductToRevenueCloudQuote` to “add the difference.”
   Do    **not** update `Quote` or delete `QuoteLineItem` with SObject All. Do
   **not** tell them to edit dates or delete lines in Salesforce. Do
   **not** rebuild the quote to drop a line.
3. Do **not** also call `applyRevenueCloudQuoteDiscount` in the same turn
   when `discountPercentage` was already passed.
4. Recap `resultsDisplay` and **Open Quote**. If they also asked for an
   email or draft, call **`draftRevenueCloudCustomerReply` next** — do
   **not** preview the PDF, do not explain, do not poll, do not compare
   the old PDF. Quantity `0` is the remove format; do not retry other
   shapes. Do not preview the PDF unless they asked for the pack or
   order form.
5. **What-if / TCV.** If they said “what if,” “make it *n* months,” a
   percent off, or “what does *n* more seats do” (to price or TCV): after
   the update, call **`getRevenueCloudBillingAndUsage`** with that
   `quoteId` and recap GrandTotal as TCV. Call explain only if they also
   asked why the price changed. Never rebuild. Never Build Quote Options
   for a term or discount tweak. Never preview the PDF.

Discount-only (no qty change): `applyRevenueCloudQuoteDiscount` with
`applyToAll=true` is fine. Then the same TCV recap when they asked what-if.

## Follow-up email (qty / term revision)

When a later email from the same customer has updated quantities or term
(days later is fine):

1. Use **Gmail** or **Outlook** to find the **newest** message from that
   customer (newest first). Read that message. Do not treat the original
   request as the source of truth for quantities or term.
2. If **this** message has a Drive Sheet or PDF (link or Drive-attached),
   or they uploaded a spreadsheet/PDF in this chat, open it now (same
   rules as inbound quote step 2). Do not wait to be told. Extract products
   and quantities from that file when present, otherwise from this email
   body, plus term (`2 years` → 24 months) and a percent off if they asked.
   Leave lines they did not mention unchanged.
3. Resolve the existing **Draft** quote:
   - Use the `quoteId` already in this chat if you have one.
   - Else **`findRevenueCloudOpenQuotes`** with `accountName` **and**
     `opportunityName` from the original email/subject. Never query
     `Quote` or `Product2` with SObject All.
   - If that Opportunity has exactly one Draft, use `latestQuoteId`.
   - If more than one Draft matches, ask which row. Do **not** guess
     and do **not** create another quote.
4. Call **`updateRevenueCloudQuoteLines` once** with that `quoteId`,
   `quantitiesJson`, and `termMonths` / `discountPercentage` when present.
5. Do **not** `createRevenueCloudQuote`. Do **not** rebuild. Do **not** call
   `buildRevenueCloudQuoteOptions`. Do **not** add delta lines. Products in
   the follow-up that are **not** on the quote: **one**
   `addProductToRevenueCloudQuote` with `linesJson` for every new SKU.
   Do not add-product per SKU. New lines inherit the quote term; do
   not pass `termMonths` unless they asked for a different term on
   that SKU. Do not explain or preview after add.
6. Recap `resultsDisplay` / `lineSummaryDisplay` and **Open Quote**.
   No PDF unless they asked. Never send mail to the customer.

## Installed base (what they own)

When the user asks what an account owns, their MRR, ARR, **current
discount**, asset lifecycle, state periods, asset actions, or how often
they add on:

1. Call **`getRevenueCloudInstalledBase` once** with `accountName`.
2. Recap `summaryDisplay` (current MRR, derived ARR, per-product **Discount**
   from the current `AssetStatePeriod`, next period if a future upsell
   exists, add-on cadence) and **Open Account** / **Open Asset**.
3. Do **not** query `Asset`, `AssetStatePeriod`, or `AssetAction` with
   SObject All. Do **not** use `Asset.CurrentMrr` (it is often 0). Do **not**
   treat quote line `Discount` as what they own — that is a Draft quote.
   ARR is **derived** (MRR × 12); Salesforce does not store ARR.
4. To change quantity on what they own, that is an amendment
   (`amendRevenueCloudAsset`), not this recap.

## New prospect (not in Salesforce)

When Create Quote says no account matched, or the email is from a company
that is not in Salesforce:

1. Show the company name, contact, and email you extracted. **Stop and
   confirm** before creating records.
2. After they confirm, call **`createRevenueCloudProspect`** with
   `accountName`, `contactFirstName` / `contactLastName`, and `contactEmail`.
   If the account has no billing street, pass the address from the email
   or `useDemoAddress=true` **only after they confirm** a demo address
   (do not invent a customer HQ). Never SObject-insert `Account` or `Contact`.
3. If `needsDisambiguation`, ask reuse vs create. Do not insert a duplicate.
4. Then **one** `createRevenueCloudQuote` with `linesJson` as usual.
5. Render **Open Account** / **Open Contact** / **Open Quote**.

## Which quote (several Drafts)

When the user says “the Acme quote” and more than one Draft might exist,
or a follow-up email has no `quoteId` in this chat:

1. Call **`findRevenueCloudOpenQuotes`** with `accountName` and
   `opportunityName` when you have it (email subject / named deal).
2. Recap `summaryDisplay` and **Open Quote** links. If more than one row,
   **ask which**. Use `latestQuoteId` when that Opportunity has one Draft
   or they said the latest / newest.
3. Do **not** query `Quote` with SObject All. Do **not** create a quote.

## Quote vs installed base

When they ask whether quote qty/discount matches what they own, or mix
a Draft 30% off with owned 8% off:

1. Call **`compareRevenueCloudQuoteToInstalledBase`** with `quoteId` (or
   quote name / account).
2. Recap `summaryDisplay`. Quote Discount is the Draft; owned Discount is
   `AssetStatePeriod`.
3. Do **not** use `Asset.CurrentMrr`. Do **not** treat quote lines as
   ownership.

## Deal status (where is this quote)

When they ask if a quote is submitted, approved, ordered, or has assets:

1. Call **`getRevenueCloudDealStatus`** with `quoteId` (or name / account).
2. Recap `summaryDisplay` and **Open Quote** / **Open Order** / **Open Asset**.
3. Do **not** submit, create an order, or activate unless they asked for that next.

## Renew or cancel an asset

1. Confirm the account, product, and **cancel vs renew**. For cancel, **stop and
   confirm** before calling the tool.
2. Get a start date and convert it to `yyyy-mm-dd`. Required for cancel.
   Required for early or expired renewals. Do not assume today.
3. Call **`renewOrCancelRevenueCloudAsset`** with `action=renew` or
   `action=cancel`. Prefer `assetId` when known. Pass `opportunityName`
   when this is tied to an email/deal.
4. Then create an order from the returned quote and activate it. Never PATCH
   `Asset`. Never use amend for a full cancel/renew.

## Draft a customer reply (unsent)

When they ask to draft a reply, recap the quote for the customer, or write
email text:

1. Call **`draftRevenueCloudCustomerReply`** with the quote (or account).
   That tool already public-links the **latest PDF on the quote**. Do
   **not** preview first.
2. Show `subject` and `bodyDisplay` in chat. Render `coachDisplay` in
   chat only (Open Quote / Open PDF for the AE).
3. If Gmail exposes a **draft / create draft** tool, put `subject` and
   `bodyDisplay` there **verbatim**. `bodyDisplay` is **HTML** — prefer
   `html` / `body_html` / `isHtml=true` when the tool has that. Keep the
   `<a href>` “proposal PDF” link. Do not paste the raw URL. Do not
   rewrite. Do not add bundle children. Do not add Salesforce or
   Lightning URLs. If that tool can attach a file, attach the proposal
   PDF. If it cannot, tell the AE to attach it from **Open PDF** and
   leave the draft unsent. If the tool is absent, leave the draft in
   chat and say “copy to Gmail compose.”
4. **Never** `send_message`, Gmail send, or Outlook send. Even if they say
   “send it,” refuse send from this skill.

## Add a PDF link to an existing draft

When they already have an unsent Gmail draft and ask to **add the PDF**,
**put the PDF link in the email**, or **include the proposal**:

1. Call **`draftRevenueCloudCustomerReply` once**. Do **not**
   `previewRevenueCloudQuoteDocument`. Do **not** explain. Do **not**
   poll. Generating a PDF is the slow path — skip it when a file
   already exists on the quote.
2. If `publicPdfUrl` is set (or `bodyDisplay` has the “proposal PDF”
   `<a href>`), **update the existing Gmail draft** with that HTML.
   Keep the rest of the draft when you can; otherwise replace the body
   with `bodyDisplay`. Do **not** create a second draft. Do **not**
   `reply` on a thread.
3. Preview **only** if `publicPdfUrl` is blank **and** `pdfUrl` is blank
   (no PDF on the quote). Then preview until `pdfUrl` in this turn, call
   draft once, and update the Gmail draft. That generate path is the
   slow one.
4. Never send.

## Customer pack (explain + PDF + unsent draft)

When they ask to **prepare the customer pack**, **ready the proposal**,
or **explain + PDF + email** for a named quote:

1. Resolve the quote (`quoteId` in this chat, else Find Open Quotes with
   `opportunityName`). Ask only if several Drafts match.
2. Call **`explainRevenueCloudQuotePrice` once**. Render `explanationDisplay`.
3. Call **`previewRevenueCloudQuoteDocument`** (RLM_QuoteProposal). On
   `isPartial` or `RETRY_NOW`, call again **immediately** with `quoteId`
   and `documentGenerationProcessId`. **Never** wait, sleep, Pause, or
   ask the user to prompt again. Keep going until `bodyDisplay` is set
   or `errorMessage` is set (safety cap 8). Finish Gmail in **this
   turn**. Do not start a second generation.
4. **When `bodyDisplay` is set:** put `subject` and `bodyDisplay` into
   Gmail **verbatim** as HTML. If a draft already exists, **update it**.
   Otherwise create a **new** Gmail draft (not a reply).
   **Never** call `draftRevenueCloudCustomerReply` after preview —
   `bodyDisplay` is already on the preview result. Keep the “proposal
   PDF” `<a href>`. No `/lightning/r/` URLs. **Never send.**
5. Do not submit, order, or activate as a side effect of the pack.

## Close this deal (submit → order → activate)

When they ask to **close this deal**, **take it to an order**, **finish
the deal**, or **activate** a named quote (not a cancel):

1. Resolve the quote (`quoteId` in this chat, else Find Open Quotes with
   `opportunityName`). Ask only if several match.
2. Call **`getRevenueCloudDealStatus`**. If an order or assets already
   exist, recap and stop — do not submit again.
3. If the quote is Draft and has lines: **`submitRevenueCloudQuoteForApproval`**.
4. If it is waiting on approval:
   - This user is the assignee: **`decideRevenueCloudQuoteApproval`**
     `decision=approve`.
   - Otherwise **stop**. Say it is waiting on the assignee. Render
     **Open Quote**. Do not invent an approval. Do not PATCH Quote.Status.
5. **`createRevenueCloudOrderFromQuote`**. Retry `isPartial` with the same
   quote. Do not insert `Order`.
6. **`activateRevenueCloudOrder`** unless they asked for a draft order
   only. Retry `isPartial` (cap 3).
7. Call **`getRevenueCloudInstalledBase`** and recap. Render **Open Quote**,
   **Open Order**, and each **Open Asset**.
8. Never PATCH Asset. Never send mail. Never skip step 4 when approval is
   still assigned to someone else.

## Ramp on an existing quote

Year-over-year qty (10 / 20 / 30) on a Draft:

1. Call **`applyRevenueCloudQuoteRamp`** with `quoteId` to describe.
2. To create the first schedule or set quantities: same tool with
   `productName` and
   `segmentsJson` `[{"quantity":10},{"quantity":20},{"quantity":30}]`.
3. Do not open Ramp Builder for the first schedule. Do not
   SObject-insert `QuoteLineGroup`. Do not rebuild the quote.

## Next bill, TCV, and usage

When they ask what they will be billed next, TCV, or usage consumed:

1. Call **`getRevenueCloudBillingAndUsage`** with `accountName` (and `quoteId`
   when the TCV is for a specific Draft).
2. Recap `summaryDisplay`. **TCV is quote GrandTotal**, not ARR, not
   `Asset.CurrentMrr`. ARR stays MRR × 12 from installed base.
3. Do **not** query `BillingSchedule`, `Invoice`, or `UsageSummary` with
   SObject All.

## Bundle configuration

1. Describe first. If it fails, show the error and stop.
2. Offer **only** the groups and products describe returned. Never invent groups.
3. Tell the user why items are already checked: required, catalog default
   (the bundle’s starting mix), or already saved on the quote. Do not imply
   they configured those themselves unless the line says already on this quote.
4. **Stop. Do not call Configure yet.** Show a picker (below) and wait.
5. After they pick, Configure with those names/SKUs. Never insert child
   `QuoteLineItem`s. Do not add the same bundle parent twice.

### Picker (required after every successful describe)

The chat cannot host a true checkbox widget. Make choosing as close to a click
as Claude allows:

- End your message with a **multiple-choice question**.
- One **optional** product per numbered line. Short **product name** only
  (SKU in parentheses is fine). Keep each line under ~60 characters so the
  client can show it as a tappable suggestion.
- Skip required items in the numbered list; mention them above as already on.
- Catalog defaults that are optional: include them as “keep default” vs
  “remove” where that helps, or list only adds and say defaults stay unless
  they say to remove.
- Number continuously across groups (1, 2, 3…) so they can answer `2 and 5`.
- Last lines of the numbered list should include:
  - `Keep the catalog defaults`
  - `Don't change anything`
- Then ask: **What do you want to add or change?** If suggestion chips
  appear, they can click those. Otherwise they can reply with numbers or names.

Example shape (use real names from describe, not this sample):

```
Catalog defaults are already selected (required Database; default API mix).
Optional adds:

1. Software Maintenance
2. QuantumBit Essentials Training
3. Additional API
4. Keep the catalog defaults
5. Don't change anything

What do you want to add or change? Click a suggestion or reply with numbers.
```

Only call `configureRevenueCloudBundle` after that reply. Map numbers back to
the describe names. If they click/type “Keep the catalog defaults”, configure
with the current [x] items (required + defaults) and no extra optionals.

## Explain quote price

When the user asks why the price is X, how you got to the number, to walk a
customer through the waterfall, or why Net Unit Price is blank on an
amendment:

1. Call `explainRevenueCloudQuotePrice` **once** with the quote (name, number,
   or Id). Pass `accountName` when known. Pass `productName` when they named a
   product (for example QuantumBit Database).
2. Do **not** query Quote, QuoteLineItem, QuoteLineDetail, or Asset with
   SObject All before or after that call. Do not “check the math” yourself.
3. Render `explanationDisplay` as the customer-facing story and stop. Do
   **not** send them to Quote Line Details or Calculation Details.
4. If the tool errors, show `errorMessage` and stop. Do not retry. Do not
   rebuild the waterfall from SObjects.
5. Blank Net Unit Price on an amendment line is expected. Never say pricing
   failed because NUP is blank.
6. Speak **list price**, **header/quote discount**, **quantity** (net add vs
   restated slices), **proration** (dates and percent of term), and
   **amount due**. Keep recipe-engine internals out of the customer reply.

## Preview quote document (order form)

Call this tool **only** when the user asks to preview the order form, quote
proposal, or PDF. Never preview as a side effect of create, add-product, or
building a quote from email.

When they do ask:

1. Call `previewRevenueCloudQuoteDocument`. Default template is
   **RLM_QuoteProposal** — do not pass `templateName` unless they named a
   different Active template. Do not use `Order_Form` (it is Draft).
2. Do **not** insert `ContentVersion` or generate a Word/PDF yourself. Do
   **not** query `DocumentGenerationProcess` with SObject All.
3. If `isPartial` is true **or** `message` starts with `RETRY_NOW`:
   - Do **not** write anything to the user (no “generating”, no “please wait”).
   - **Never** use a Wait tool, sleep, bash `sleep`, or “Wait for the
     PDF to finish generating.” Call the same tool **immediately**.
   - Call again with `quoteId` and `documentGenerationProcessId` from
     the last result.
   - Repeat until `pdfUrl` / `bodyDisplay` is set or `errorMessage` is
     set (safety cap 8). Finish in **this turn**. Never ask the user to
     prompt again. Do not start a new generation. Do not Pause.
4. When `pdfUrl` is set, render **Open PDF** and **Open Quote**. Preview
   also returns `publicPdfUrl` and HTML `bodyDisplay`. Use those for
   email. Do **not** call `draftRevenueCloudCustomerReply`.
5. A later preview of the same unchanged quote returns the existing PDF on
   the first call. Do not start a new generation and do not tell the user
   you are regenerating.

When they ask to **regenerate the PDF and refresh the email draft**:

1. Call `previewRevenueCloudQuoteDocument` (no extra flags required).
2. Poll as above — **immediately**, never wait/Pause. Stay in this turn
   until `bodyDisplay` is set.
3. When `bodyDisplay` is set, **update the existing Gmail draft** with
   that HTML. Keep the proposal PDF `<a href>`. **Never** call
   `draftRevenueCloudCustomerReply`. Do **not** create a second draft.
   Never send. Never ask them to prompt again.

## Order and assets

If they asked to **close this deal** / take it to an order **and
activate**, follow **Close this deal** (submit and decide first). For
order-only or activate-only:

1. Create the order from the quote (`createRevenueCloudOrderFromQuote`). If
   `isPartial` (quote still pricing), call again with the same quote. Do not
   insert an `Order`.
2. Then activate (`activateRevenueCloudOrder`) unless the user only wanted a
   draft order. If `isPartial`, **immediately call again** with the same
   `orderId` (up to 3 times) until `isPartial` is false or there is an error.
3. Render **Open Order** and each **Open Asset** link. Assets are created
   asynchronously after activation; an empty first activate is normal.

The account must have a Contact (Bill to Contact) and a billing or shipping
address. Create Prospect writes those when you pass an address or confirmed
`useDemoAddress`. Create Quote stamps `Quote.ContactId` from `contactEmail`
or the account contact. If activation still says those are missing, tell
the user — do not invent a customer HQ.

## Amend an asset

1. Look up the asset with SObject All if you need to confirm account, product,
   and current quantity. Prefer a named child product such as **QuantumBit
   Database**, not the **Complete** parent, unless the user names the parent.
2. **Get a start date, then convert it to `yyyy-mm-dd` before the tool call.**
   Spoken dates are fine in chat (`October 28th 2026`, `Oct 28 2026`, `today`).
   Never pass month names, ordinals, or `mm/dd/yyyy` into `startDate`.
   If the user already named a date, convert it and do **not** ask again.
   If they did not, **stop and ask**. Do not assume today. Offer a picker:

```
When should this amendment start?

1. Today (YYYY-MM-DD)
2. I'll type a different date

What start date should I use?
```

   Replace `YYYY-MM-DD` with today's real date. If they pick 1, use that date.
   If they type or say a date, convert it to `yyyy-mm-dd` (example:
   October 28th 2026 → `2026-10-28`).
3. Call `amendRevenueCloudAsset` with `quantityChange` as a **delta** (5 adds
   five; -2 removes two) and required `startDate`. Pass `assetId` when known;
   otherwise `accountName` + `productName`. If the named product is a **bundle
   component** (for example QuantumBit Database under Complete), still call
   this tool with that product name. Pass `opportunityName` when this came
   from an email thread. The tool amends the top-level parent and
   applies the delta to the component line. Do **not** refuse, and do **not**
   add the quantity to Complete instead.
4. If `needsDisambiguation`, ask which asset. If `isPartial`, call again with
   the same asset and start date.
5. The tool creates an **amendment Quote**. Then create an order from that
   quote and activate it so the asset updates. Do not stop after the amend
   quote unless the user only wanted a draft quote.
6. Render **Open Quote** and **Open Asset**. Never PATCH `Asset.Quantity`.

## Guardrails

- Draft quotes only for quote mutate tools (add/configure/discount). Creating
  an order from a priced quote is allowed while the quote is still Draft.
- Ask the user to pick when a name matches more than one quote, order, or product.
- One-Time products cannot inherit a term billing frequency; the configure tool
  handles that. Q-Rack 750 / One-Time hardware bundles: add at **quantity 1**.
  On `Cannot have a fractional quantity` with qty > 1, retry add at
  quantity 1 once and say it is sold per rack. Do not drop the other lines.
  Do not create a second quote. Other save failures: show the Salesforce
  error and stop.
- Keep recaps names-only (quote name, product, qty, discount). No raw org
  Ids; clickable Lightning URLs from `quoteUrl` / `opportunityUrl` /
  `orderUrl` / `assetUrl` / `assetsDisplay` are required.
- `quantityChange` on amend is a delta, never the resulting quantity.
- Never assume today's date for an amendment. Ask only if they did not
  already give one. Convert whatever they said to `yyyy-mm-dd` before the
  tool call.
- Bundle components cannot be the `initiateAmendment` target. The Amend
  Asset tool walks to the parent and patches the component line. Do not
  tell the user they must add quantity on Complete instead.
- Price explanations: one `explainRevenueCloudQuotePrice` call. Never
  reconstruct list/discount/proration with SObject All.
- Quote document preview / draft the current quote email: Preview until
  `bodyDisplay` **in this turn**. Never wait, Pause, or ask the user to
  retry. Success returns `bodyDisplay` + `publicPdfUrl` — update Gmail.
  **Never** `draftRevenueCloudCustomerReply` after preview.
- Customer pack: explain once, preview until `bodyDisplay` in this
  turn, then Gmail that HTML. Never Draft after Preview. Never send.
- Close this deal: deal status first; submit Draft; decide only if this
  user is the assignee; else stop. Then order + activate + installed
  base. Never PATCH Quote.Status or Asset.
- What-if on a Draft: one Update Quote Lines, then TCV from
  `getRevenueCloudBillingAndUsage`. Never rebuild.
- Next-best-action: one Next line after every successful mutate.
- Inbound calendar / call recap: Google Calendar (or Microsoft 365
  calendar) for read only. Never create, update, or delete events. Never
  send a calendar invite. Open the event description and Drive notes
  immediately — do not wait to be told. Recording-only events cannot be
  transcribed; say so. `startDate` from the event. `contactEmail` from a
  customer attendee, not you. Same create/reuse/amend rules as inbound
  email.
- Inbound email: Gmail/Outlook for read only. Never send mail to the
  customer. Drive Sheet or PDF (link or Drive-attached), or a file
  uploaded in this chat: open it immediately and quote those lines — do
  not wait to be told. Prefer a Sheet over a PDF when both exist. A
  downloaded `.xlsx` / `.csv` / `.pdf` with no Drive URL cannot be read;
  say so. Do not treat our Quote Proposal PDF as an inbound request.
  Always pass `opportunityName` + `quoteName`. New mix: one create with
  `linesJson`. Same request again: `alreadyExisted` or
  `findRevenueCloudOpenQuotes` then update — never a second Draft. No
  account: confirm, then `createRevenueCloudProspect` (address or
  confirmed `useDemoAddress`). They already own the SKU: amend, not
  create. Follow-up qty email: newest message (and its sheet/PDF if
  present), find with `opportunityName`, then one
  `updateRevenueCloudQuoteLines`. New SKUs on that Draft: one add with
  `linesJson` (inherits quote term; recap only — never explain or
  preview after add). Never SObject-insert Account. Never SObject All on
  Product2, never add-product per SKU, never Build Quote Options, never
  summary, never preview unless they ask.
- Quote vs owned: `compareRevenueCloudQuoteToInstalledBase`. Do not mix
  quote Discount with `AssetStatePeriod.Discount`.
- Deal status: one `getRevenueCloudDealStatus`. Read only.
- Renew/cancel: confirm cancel, then `renewOrCancelRevenueCloudAsset`. Then
  order + activate. Never PATCH Asset.
- Customer reply after a line change: update once (quantity 0 to
  remove), then `draftRevenueCloudCustomerReply`. That includes a
  customer-safe PDF link from the latest file. Do not preview or wait
  for a new PDF. Gmail draft/create with `bodyDisplay` verbatim.
  No Lightning URLs. Never send mail.
- Add a PDF link to an existing unsent Gmail draft: one
  `draftRevenueCloudCustomerReply`, then update that Gmail draft.
  Never preview. Never explain. Never a second draft. Never send.
- Ramp: `applyRevenueCloudQuoteRamp` creates the first yearly schedule
  or patches existing segments. Do not open Ramp Builder for 10/20/30.
- Approver: `decideRevenueCloudQuoteApproval`. Never PATCH Quote.Status.
- After reconnect: `getRevenueCloudQuotingCatalog`, then find with
  `opportunityName`.
- Next bill / TCV / usage: `getRevenueCloudBillingAndUsage`. TCV ≠ ARR.
- Qty, remove a line (quantity 0), term, start date, discount, or quote
  name on an existing Draft quote: one `updateRevenueCloudQuoteLines`
  (`termMonths`: 5 years = 60; `startDate`: yyyy-mm-dd; `quoteName` to
  rename). Never rebuild. Never SObject-update Quote. Never
  SObject-delete QuoteLineItem.
  Never Build Quote Options for a term change. Never add extra lines for a
  quantity change.
- Add a SKU to an existing Draft: one `addProductToRevenueCloudQuote`
  with `linesJson`. New lines inherit the quote term unless they asked
  for a different term on that SKU. Recap `lineSummaryDisplay` + Open
  Quote. Never explain or preview after add. On connector timeout, do
  not retry add — summary once, then stop.
- Installed base / MRR / ARR / current discount / add-ons: one
  `getRevenueCloudInstalledBase`. Discount is `AssetStatePeriod.Discount`.
  ARR = current period MRR × 12. Never `Asset.CurrentMrr`. Never quote lines
  as ownership.
